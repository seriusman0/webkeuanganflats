<footer id="footer">
    <div class="text-center clearfix">
        <p><small>&copy 2020 - Develop By Biro Keuangan FLATS - www.flats.id</small>
            <br /><br />
            <a href="https://www.instagram.com/flatsindonesia/" class="btn btn-xs btn-circle btn-instagram"><i class="fa fa-instagram"></i></a>
            <a href="https://www.facebook.com/flats.2005" class="btn btn-xs btn-circle btn-facebook"><i class="fa fa-facebook"></i></a>
        </p>
    </div>
</footer>